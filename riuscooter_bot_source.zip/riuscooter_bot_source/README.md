# RiuScooter Bot

This is the source code for the RiuScooter repair and spare parts chatbot.